# AppIntro Docs

Please find here the documentation for AppIntro.

## Changelogs

The full changelog is available in the [CHANGELOG](/CHANGELOG.md) page. Please visit also the [release page](https://github.com/AppIntro/AppIntros/releases) as shorter release notes are published also there.

## Migration guides

If you need support migrating from older versions please read:

* [Migrating from 5.x to 6.x](migrating-from-5.0.md)