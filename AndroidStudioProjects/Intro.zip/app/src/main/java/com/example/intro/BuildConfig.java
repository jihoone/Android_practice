/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.example.intro;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String LIBRARY_PACKAGE_NAME = "com.github.appintro";
  public static final String BUILD_TYPE = "debug";
  public static final int VERSION_CODE = 20;
  public static final String VERSION_NAME = "6.0.0";
}
